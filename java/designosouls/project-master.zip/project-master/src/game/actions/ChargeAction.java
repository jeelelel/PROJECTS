package game.actions;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Weapon;
import game.weapons.StormRuler;

public class ChargeAction extends Action {

    Weapon weapon;
    
    /**
     * Constructor
     * @param weapon    weapon to charge
     */
    public ChargeAction(Weapon weapon){
        this.weapon = weapon;
    }

    /**
     * This method executes the charge action
     * @param actor actor executing the action
     * @param map   game map
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        ((StormRuler) weapon).charge();
        return menuDescription(actor);
    }

    /**
     * Print on menu console
     * @param actor The actor performing the action.
     * @return String actor + " charges " + ((Item) weapon).toString()
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " charges " + ((Item) weapon).toString();
    }
}
