package game.actions;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import game.manager.BonfireManager;
import game.enums.Abilities;

import java.util.HashMap;

/**
 * Class of player action to activate the unactivated bonfire
 */
public class ActivateBonfireAction extends Action {
    /**
     * Empty constructor
     */
    public ActivateBonfireAction() {
    }

    /**
     * Activate the bonfire by adding their Abilities which is activated so can let player rest and teleport and add
     * them to the hashmap of the Bonfire Manager containing all activated bonfire
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String "Player lights the Bonfire"
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.locationOf(actor).getGround().addCapability(Abilities.ACTIVATED);
        BonfireManager.getInstance().addBonfire(BonfireManager.getInstance().getNextActivatedKey(), map.locationOf(actor));
        HashMap<Integer,Location> newDestinations =  BonfireManager.getInstance().getBonfireDestinations();
        return "Player lights the Bonfire";
    }

    /**
     * Print string at the player menu console
     * @param actor The actor performing the action.
     * @return String "Lit Bonfire"
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Lit Bonfire";
    }
}
