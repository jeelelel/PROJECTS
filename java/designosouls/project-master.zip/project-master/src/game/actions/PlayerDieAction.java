package game.actions;

import edu.monash.fit2099.engine.*;
import edu.monash.fit2099.engine.Action;
import game.manager.BonfireManager;
import game.manager.ResetManager;
import game.actors.Player;
import game.enums.Abilities;

/**
 * Action when player die
 */
public class PlayerDieAction extends Action {
    /**
     * Empty constructor
     */
    public PlayerDieAction() {
    }

    /**
     * When player die, move player to bonfire and Reset Everything
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String "Player died" when it died and nothing when not die
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        //make sure is for Player only
        if (actor.hasCapability(Abilities.RESET)) {
            if (!actor.isConscious()) {
                //move player at BonFire
                //map.moveActor(actor, map.at(38,11)); //manually at Bonfire
                Player player = (Player) actor;
                Integer key = player.getLastBonfireKey();
                Location reviveLoc = BonfireManager.getInstance().getBonfireDestinations().get(key);
                map.moveActor(actor, reviveLoc);

                String die = "\n" +
                        "   _ (`-.              ('-.                    ('-.  _  .-')         _ .-') _              ('-.  _ .-') _   \n" +
                        "  ( (OO  )            ( OO ).-.              _(  OO)( \\( -O )       ( (  OO) )           _(  OO)( (  OO) )  \n" +
                        " _.`     \\ ,--.       / . --. /  ,--.   ,--.(,------.,------.        \\     .'_   ,-.-') (,------.\\     .'_  \n" +
                        "(__...--'' |  |.-')   | \\-.  \\    \\  `.'  /  |  .---'|   /`. '       ,`'--..._)  |  |OO) |  .---',`'--..._) \n" +
                        " |  /  | | |  | OO ).-'-'  |  | .-')     /   |  |    |  /  | |       |  |  \\  '  |  |  \\ |  |    |  |  \\  ' \n" +
                        " |  |_.' | |  |`-' | \\| |_.'  |(OO  \\   /   (|  '--. |  |_.' |       |  |   ' |  |  |(_/(|  '--. |  |   ' | \n" +
                        " |  .___.'(|  '---.'  |  .-.  | |   /  /\\_   |  .--' |  .  '.'       |  |   / : ,|  |_.' |  .--' |  |   / : \n" +
                        " |  |      |      |   |  | |  | `-./  /.__)  |  `---.|  |\\  \\        |  '--'  /(_|  |    |  `---.|  '--'  / \n" +
                        " `--'      `------'   `--' `--'   `--'       `------'`--' '--'       `-------'   `--'    `------'`-------'  \n";
                //reset everything
                ResetManager.getInstance().run();
                return die;
            }
        }
        return null;
    }

    /**
     * No Display the Description of this action at menu
     * @param actor The actor performing the action.
     * @return null
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }

    /**
     * No Display the Description of this action at menu, not hotKey
     * @return null
     */
    @Override
    public String hotkey() {
        return null;
    }

}
