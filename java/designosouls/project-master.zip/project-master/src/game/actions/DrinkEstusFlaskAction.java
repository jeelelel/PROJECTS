package game.actions;

import edu.monash.fit2099.engine.*;
import game.items.EstusFlask;
import game.enums.Abilities;

/**
 * This is an action that allows player to drink potion/ Estus Flask
 */
public class DrinkEstusFlaskAction extends Action {
    /**
     * Available charges to be used
     */
    int chargesAvailable;
    /**
     * The Estus Flask Potion itself to drink
     */
    EstusFlask potion;
    /**
     * The Hotkey for drink Estus Flask
     */
    protected String hotKey;

    /**
     * Constructor for player to Drink Estus Flask
     * @param estusFlask Player's Estus Flask
     */
    public DrinkEstusFlaskAction(EstusFlask estusFlask) {
        potion = estusFlask;
        this.hotKey = "a";
    }

    /**
     * if the actor has capability to drink estus flask (Player) then drink Estus Flask
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String whether Actor drink Estus Flask or not
     */
    public String execute(Actor actor, GameMap map) {
        if (actor.hasCapability(Abilities.DRINK_ESTUS_FLASK)){
            if(potion.drinkEstusFlask()){
                return actor + "drank Estus Flask";
            }        }
        return actor + "drank nothing";
    }

    /**
     * Display at menu the option to drink Estus Flask and show its remaining charges
     * @param actor The actor performing the action.
     * @return String Player drinks Estus Flask (?/3)
     */
    @Override
    public String menuDescription(Actor actor) {
        if (actor.hasCapability(Abilities.DRINK_ESTUS_FLASK)) {
            chargesAvailable = potion.getCharges();
            return actor + " drinks Estus Flask(" + chargesAvailable + "/3)"; //+ player.potion;
        }
        return null;
    }

    /**
     * As this is the first item of player it will be a, but can be changed to 'a' but its display will
     * be alone at top before number which is weird so better this.
     * @return String 'a'
     */
    @Override
    public String hotkey() {
        return super.hotkey();
    }

}
