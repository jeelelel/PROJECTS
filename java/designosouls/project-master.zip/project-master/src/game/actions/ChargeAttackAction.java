package game.actions;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Weapon;
import game.weapons.MeleeWeapon;
import game.enums.Status;

public class ChargeAttackAction extends AttackAction {

	/**
	 * Constructor
	 * @param target	attack target
	 * @param direction	attack direction
	 */
    public ChargeAttackAction(Actor target, String direction) {
        super(target, direction);
    }

	/**
	 * This method executes the charge attack
	 * @param actor	attacker
	 * @param map	game map
	 */
    @Override
    public String execute(Actor actor, GameMap map) {

        Weapon weapon = actor.getWeapon();

        ((MeleeWeapon) weapon).chargeAttack();

        int damage = weapon.damage();
		String result = actor + " " + weapon.verb() + " " + target + " for " + damage + " damage.";
		target.hurt(damage);

        target.addCapability(Status.STUNNED);
        ((MeleeWeapon) weapon).reset_hitrate();
        
        if (!target.isConscious()) {
			Actions dropActions = new Actions();
			// drop all items
			for (Item item : target.getInventory())
				dropActions.add(item.getDropAction(actor));
			for (Action drop : dropActions)
				drop.execute(target, map);
			// remove actor
			map.removeActor(target);
			result += System.lineSeparator() + target + " is killed.";
		}

		return result;
    }
    
}