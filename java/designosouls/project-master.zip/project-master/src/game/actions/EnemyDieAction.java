package game.actions;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.enums.Abilities;
import game.interfaces.Soul;
import game.items.CinderOfTheLord;

/**
 * Action to check whether enemy has die or not for enemy
 */
public class EnemyDieAction extends Action {
    /**
     * Get the player soul to transfer
     */
    private Soul playerSoul;

    /**
     * Constructor for when enemy dies
     */
    public EnemyDieAction() {
    }

    /**
     * Transfer soul of the enemy to player when it dies and return the String to inform it
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String Enemy is Dead if it's dead and return nothing when enemy is still alive
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (!actor.isConscious()) {
            if (actor.hasCapability(Abilities.DROP_CINDER_OF_LORD)){
                map.locationOf(actor).addItem(new CinderOfTheLord());
            }
            //Remove Undead
            map.removeActor(actor);
            return actor + " is Dead";
        }
        return null;
    }

    /**
     * To not show anything at menu description coz this is not for player to choose
     * @param actor The actor performing the action.
     * @return null
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }

    /**
     * To not show anything at menu description coz this is not for player to choose, no hotkey to choose
     * @return null
     */
    @Override
    public String hotkey() {
        return null;
    }


}
