package game.actions;

import edu.monash.fit2099.engine.*;
import game.actors.Player;
import game.enums.Abilities;

/**
 * Action to move to other bonfire by extending the MoveACtorAction as it was really similar
 */
public class BonfireMoveAction extends MoveActorAction {
    /**
     * Integer key of the bonfire ID destination
     */
    Integer key;

    /**
     * Constructor extending the Move Actor Action but gives information to the Player instance of last teleported bonfire
     * @param moveToLocation Location of the bonfire
     * @param direction String of the bonfire destination info
     * @param hotKey the hotkey (can null)
     * @param bonfireCode The bonfire ID destination
     */
    public BonfireMoveAction(Location moveToLocation, String direction, String hotKey, Integer bonfireCode) {
        super(moveToLocation, direction, hotKey);
        key = bonfireCode;
    }

    /**
     * Execute function
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String of the menu description
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (actor.hasCapability(Abilities.RESET)){
            Player player = (Player) actor;
            player.setActivatedBonfire(key);
        }
        return super.execute(actor, map);
    }
}
