package game.actions;

import java.util.Random;

import edu.monash.fit2099.engine.*;
import game.weapons.MeleeWeapon;
import game.items.TokenOfSouls;
import game.enums.Abilities;
import game.enums.Status;

/**
 * Special Action for attacking other Actors.
 */
public class AttackAction extends Action {

	/**
	 * The Actor that is to be attacked
	 */
	protected Actor target;

	/**
	 * The direction of incoming attack.
	 */
	protected String direction;

	/**
	 * Random number generator
	 */
	protected Random rand = new Random();

	/**
	 * Constructor.
	 * 
	 * @param target the Actor to attack
	 */
	public AttackAction(Actor target, String direction) {
		this.target = target;
		this.direction = direction;
	}
	
	public AttackAction(Actor target){
	    this.target = target;
	}

	/**
	 * Attack action for actors to another target based on its weapon
	 * @param actor The actor performing the action.
	 * @param map The map the actor is on.
	 * @return String whether actor missed target or target is killed in string
	 */
	@Override
	public String execute(Actor actor, GameMap map) {

		Weapon weapon = actor.getWeapon();

		if (actor.hasCapability(Status.HOSTILE_TO_ENEMY) && ((Item) weapon).hasCapability(Status.LIGHTNING_BUFFED)){
			((MeleeWeapon) weapon).lightning_charged_attack();
		}

		if (!(rand.nextInt(100) <= weapon.chanceToHit())) {
			return actor + " misses " + target + ".";
		}

		int damage = weapon.damage();
		String result = actor + " " + weapon.verb() + " " + target + " for " + damage + " damage.";
		target.hurt(damage);
		if (!target.isConscious()) {
			Actions dropActions = new Actions();
			// drop all items
			for (Item item : target.getInventory())
				dropActions.add(item.getDropAction(actor));
			for (Action drop : dropActions)
				drop.execute(target, map);
			// remove actor
			//TODO: In A1 scenario, you must not remove a Player from the game yet. What to do, then?
			if (target.hasCapability(Abilities.DRINK_ESTUS_FLASK)) {
				map.locationOf(target).addItem(new TokenOfSouls(target.asSoul()));
			}
			else {
				target.asSoul().transferSouls(actor.asSoul());
			}
			result += System.lineSeparator() + target + " is killed.";
		}

		return result;
	}

	/**
	 * Show on menu description
	 * @param actor The actor performing the action.
	 * @return String which actor attacks which target at what direction
	 */
	@Override
	public String menuDescription(Actor actor) {
		return actor + " attacks " + target + " at " + direction;
	}
}
