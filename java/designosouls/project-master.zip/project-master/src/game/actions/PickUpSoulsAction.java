package game.actions;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.items.TokenOfSouls;

/**
 * Pick Up Token of Souls Action extended from Action
 */
public class PickUpSoulsAction extends Action {
    /**
     * The token of souls dropped
     */
    private TokenOfSouls tokenSouls;

    /**
     * Constructor of this action
     * @param tokenSouls the token dropped at that location
     */
    public PickUpSoulsAction(TokenOfSouls tokenSouls) {
        this.tokenSouls = tokenSouls;
    }

    /**
     * When player take the token, it will be removed from map and transfer its soul to Player
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String Player get the Token
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.locationOf(actor).removeItem(tokenSouls);
        tokenSouls.transferSouls(actor.asSoul());
        return "Player get Token";
    }

    /**
     * Set up menu for player to take the Token Os Souls
     * @param actor The actor performing the action.
     * @return String "Picks up Player's Token of Souls"
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Picks up Player's Token of Souls";
    }

    /**
     * Get the next hotkey usually after Estus Flask
     * @return char alphabet usually b
     */
    @Override
    public String hotkey() {
        return super.hotkey();
    }
}
