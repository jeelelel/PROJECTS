package game.actions;

import edu.monash.fit2099.engine.*;
import game.items.GoldPineResin;

/**
 * This is an action that allows player to drink potion/ Estus Flask
 */
public class LightningBuffsAction extends Action {
    /**
     * Available charges to be used
     */
    int chargesAvailable;
    /**
     * The Gold Pine Resin
     */
    GoldPineResin pineResin;
    /**
     * The Hotkey for apply Gold Pine Resin
     */
    protected String hotKey;

    /**
     * Constructor for player to apply Gold Pine Resin
     * @param goldPineResin Player's Gold Pine Resin
     */
    public LightningBuffsAction(GoldPineResin goldPineResin) {
        pineResin = goldPineResin;
        this.hotKey = "g";
    }

    /**
     * if the actor has capability to apply Gold Pine Resin (Player) then applies it
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String whether Actor drink Estus Flask or not
     */
    public String execute(Actor actor, GameMap map) {
        if(pineResin.chargeWeapon()){
            return actor + "applies lightning buff to weapon";
        }
        return actor + "ran out of gold pine resin";
    }

    /**
     * Display at menu the option to apply Gold Pine Resin and show its remaining charges
     * @param actor The actor performing the action.
     * @return String Player applies Gold Pine Resin (?/3)
     */
    @Override
    public String menuDescription(Actor actor) {
        chargesAvailable = pineResin.getCharges();
        return actor + " applies Gold Pine Resin(" + chargesAvailable + "/3)";
    }
}
