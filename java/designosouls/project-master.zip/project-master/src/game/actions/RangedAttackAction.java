package game.actions;

import edu.monash.fit2099.engine.*;
import game.actions.AttackAction;

/**
 * Special Action for attacking other Actors.
 */
public class RangedAttackAction extends AttackAction {

	/**
	 * Constructor.
	 * 
	 * @param target the Actor to attack
	 */
	public RangedAttackAction(Actor target, String direction) {
		super(target, direction);
	}
	
	public RangedAttackAction(Actor target){
        super(target);
	}

	/**
	 * Attack action for actors to another target based on its weapon
	 * @param actor The actor performing the action.
	 * @param map The map the actor is on.
	 * @return String whether actor missed target or target is killed in string
	 */
	@Override
	public String execute(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);
		Location there = map.locationOf(target);

		int currentDistance = distance(here, there);
        while (currentDistance > 0){
            for (Exit exit : here.getExits()) {
                Location destination = exit.getDestination();
                int newDistance = distance(destination, there);
                if (newDistance < currentDistance) {
                    here = destination;
					currentDistance = distance(here, there);
					if (here.getGround().blocksThrownObjects()){
						return actor + " misses " + target + ".";
					}
                }
            }
        }
		if (here.getGround().blocksThrownObjects()){
			return actor + " misses " + target + ".";
		}

		return super.execute(actor, map);
	}

    /**
	 * Compute the Manhattan distance between two locations.
	 * 
	 * @param a the first location
	 * @param b the first location
	 * @return the number of steps between a and b if you only move in the four cardinal directions.
	 */
	private int distance(Location a, Location b) {
		return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
	}
}
