package game.actions;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.manager.ResetManager;
import game.grounds.Bonfire;

/**
 * Rest at bonfire Action
 */
public class RestAtBonfireAction extends Action {
    Bonfire bonfire;
    /**
     * Empty Constructor
     */
    public RestAtBonfireAction(Bonfire newBonfire) {
        bonfire = newBonfire;
    }

    /**
     * When player choose to REST reset by Reset Manager
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String Actor + "Rested at Firelink Shrine Bonfire"
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        ResetManager.getInstance().run();
        //bonfire = (Bonfire) map.locationOf(actor).getGround();
        return actor + "Rested at "+ bonfire +"'s Bonfire";
    }

    /**
     * Add menu decription to Rest at Firelink Shrine Bonfire
     * @param actor The actor performing the action.
     * @return String "Rest at Firelink Shrine Bonfire"
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Rest at "+ bonfire +"'s Bonfire";
    }

    /**
     * Hotkey to choose to rest at Bonfire
     * @return String alphabet usually b
     */
    @Override
    public String hotkey() {
        return super.hotkey();
    }
}
