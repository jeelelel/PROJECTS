package game.actors;

import edu.monash.fit2099.engine.*;
import game.actions.AttackAction;
import game.actions.ChargeAttackAction;
import game.behaviours.FollowBehaviour;
import game.behaviours.RangedAttackBehaviour;
import game.enums.Abilities;
import game.enums.Status;
import game.interfaces.Behaviour;
import game.weapons.DarkmoonLongbow;

/**
 * Yhorm the Giant, boss under the Lord of Cinder title
 */
public class AldrichTheDevourer extends LordOfCinder {

    private Actor target;

    /**
     * Constructor
     */
    public AldrichTheDevourer() {
        super("Aldrich the Devourer", 'A', 350);
        this.addCapability(Abilities.EMBER_FORM);
        this.setSoul(5000);
        DarkmoonLongbow darkmoonLongbow = new DarkmoonLongbow();
        this.addItemToInventory(darkmoonLongbow);
    }

    /**
     * Add allowable actions such as Follow behaviour and attack action, as all enemy has that parts
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return Actions the actions
     */
    @Override
	public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            target = otherActor;
        }
        Actions actions = new Actions();
		// it can be attacked only by the HOSTILE opponent, and this action will not attack the HOSTILE enemy back.
		if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
		    //add behaviour to follow Player
            this.getBehaviours().add(0, new FollowBehaviour(otherActor));
            for(Behaviour Behaviour : this.getBehaviours()) {
                Action behaviourAction = Behaviour.getAction(this, map);
                actions.add(behaviourAction);
            }
            Weapon weapon = otherActor.getWeapon();
			if (weapon.getClass() != IntrinsicWeapon.class && ( (Item) weapon).hasCapability(Status.CHARGED)){
				actions.add(new ChargeAttackAction(this, direction));
			}
			else{
				actions.add(new AttackAction(this,direction));
			}
		}
        return actions;
	}

    /** 
     * This method returns action for Aldrich
     * @param actions       list of actions
     * @param lastAction    last action
     * @param map           game map
     * @param display       display
     * @return Action
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        if (target != null){
            Action rangedAttackAction = new RangedAttackBehaviour(target).getAction(this, map);
            if (rangedAttackAction != null){
                rangedAttackAction.execute(this, map);
            }
        }
        return super.playTurn(actions, lastAction, map, display);
    }   
}
