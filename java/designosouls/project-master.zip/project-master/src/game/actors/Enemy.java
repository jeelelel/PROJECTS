package game.actors;

import java.util.ArrayList;

import edu.monash.fit2099.engine.*;
import game.actions.EnemyDieAction;
import game.behaviours.FollowBehaviour;
import game.weapons.MeleeWeapon;
import game.actions.AttackAction;
import game.actions.ChargeAttackAction;
import game.interfaces.Resettable;
import game.interfaces.Soul;
import game.enums.Status;
import game.interfaces.Behaviour;

/**
 * Class representing enemies
 */
public abstract class Enemy extends Actor implements Soul, Resettable {
    /**
     * Soul given
     */
    private int soul;
    /**
     * if want to display menu
     */
    private final Menu menu = new Menu();
    /**
     * Array List of Behaviours
     */
    private ArrayList<Behaviour> behaviours = new ArrayList<>();

    /**
     * Constructor and register class for when reset
     * @param name Name of the enemies
     * @param displayChar Displayed Char as
     * @param hitPoints the initial maxHitPoints and hitPoints
     */
    public Enemy(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.registerInstance();
    }

    /**
     * Getter for behaviours
     * @return ArrayList of Behaviours
     */
    public ArrayList<Behaviour> getBehaviours() {
        return behaviours;
    }

    /**
     * Add allowable actions such as Follow behaviour and attack action, as all enemy has that parts
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return Actions the actions
     */
    @Override
	public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
		Actions actions = new Actions();
		// it can be attacked only by the HOSTILE opponent, and this action will not attack the HOSTILE enemy back.
		if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
		    //add behaviour to follow Player
            behaviours.add(0, new FollowBehaviour(otherActor));
            for(Behaviour Behaviour : behaviours) {
                Action behaviourAction = Behaviour.getAction(this, map);
                actions.add(behaviourAction);
            }
            Weapon weapon = otherActor.getWeapon();
			if (weapon.getClass() != IntrinsicWeapon.class && ( (Item) weapon).hasCapability(Status.CHARGED)){
				actions.add(new ChargeAttackAction(this, direction));
			}
			else{
				actions.add(new AttackAction(this,direction));
			}
			AttackAction attackAction = new AttackAction(otherActor, direction);
			attackAction.execute(this, map);
		}
		return actions;
	}

    /**
     * At each play turn return attackAction, Behaviour or Do nothing
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return Action what to do at that turn
     */
    @Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        if (!isConscious()){
            return new EnemyDieAction();
        }
		// loop through all behaviours
        for(Behaviour Behaviour : behaviours) {
			Action action = Behaviour.getAction(this, map);
			if (action != null){
			    for (Action action1 : actions){
			        if (action1 instanceof AttackAction){
			            return action1;
                    }
                }
                return action;
            }
		}
		return new DoNothingAction();
	}

    /**
     * Transfer soul to another soul when die
     * @param soulObject a target souls.
     */
    public void transferSouls(Soul soulObject) {
        //TODO: transfer Enemy's souls to another Soul's instance.
        int currentSoul = this.soul;
        soulObject.addSouls(currentSoul); //add another soul it's soul
    }

    /**
     * Set soul
     * @param soul
     */
    public void setSoul(int soul) {
        this.soul = soul;
    }

    /**
     * reset instances
     */
    @Override
    public void resetInstance() {
        //this.hurt(maxHitPoints);
    }

    /**
     * Make sure it exist to reset
     * @return
     */
    @Override
    public boolean isExist() {
        return true;
    }

    /**
     * When hurt minus hitPoints
     * @param points number of hitpoints to deduct.
     */
    @Override
    public void hurt(int points) {
        super.hurt(points);
        hitPoints = Math.max(hitPoints,0);
    }

    /**
     * To String Method to show every enemy at the History log or Console when enemy is found
     * @return String name + " (" + this.hitPoints + "/" + this.maxHitPoints + ")" + " holds " + getWeapon().toString();
     */
    @Override
    public String toString() {
        if (this.getWeapon() instanceof MeleeWeapon) {
            return name + " (" + this.hitPoints + "/" + this.maxHitPoints + ")" + " holds " + getWeapon().toString();
        }
        else {return name + " (" + this.hitPoints + "/" + this.maxHitPoints + ")";}
    }
}
