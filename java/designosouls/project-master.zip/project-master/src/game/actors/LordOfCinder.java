package game.actors;

import edu.monash.fit2099.engine.*;
import game.actors.Enemy;
import game.enums.Abilities;
import game.weapons.BroadSword;
import game.weapons.DarkmoonLongbow;
import game.weapons.MeleeWeapon;
import game.weapons.StormRuler;

/**
 * The boss of Design o' Souls
 * FIXME: This boss is Boring. It does nothing. You need to implement features here.
 * TODO: Could it be an abstract class? If so, why and how?
 */
public abstract class LordOfCinder extends Enemy {
    /**
     * Constructor.
     */
    public LordOfCinder(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.addCapability(Abilities.DROP_CINDER_OF_LORD);
    }

    /**
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return DoNothingAction
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        Weapon weapon = this.getWeapon();
        if (weapon instanceof StormRuler){
            ( (StormRuler) weapon ).critStrike();
        }
        else {
            ( (DarkmoonLongbow) weapon ).critStrike();
        }
        return super.playTurn(actions, lastAction, map, display);
    }
}