package game.actors;


import edu.monash.fit2099.engine.*;
import game.behaviours.WanderBehaviour;
import game.enums.Status;
import java.util.Random;

/**
 * An undead minion.
 */
public class Undead extends Enemy {

	/** 
	 * Constructor.
	 * All Undeads are represented by an 'u' and have 30 hit points.
	 * @param name the name of this Undead
	 */
	public Undead(String name) {
		super(name, 'u', 50);
		this.addCapability(Status.SPAWNED);
		this.getBehaviours().add(new WanderBehaviour());
		this.setSoul(50);
		this.registerInstance();
	}

	/**
	 * Reset Instance by hurt this Undead then will be wiped at the play turn Enemy Die Action
	 */
	@Override
	public void resetInstance() {
		this.hurt(maxHitPoints);
	}

	/** 
	 * This method overrides the base attack for undead
	 * @return IntrinsicWeapon
	 */
	@Override
	protected IntrinsicWeapon getIntrinsicWeapon() {
	    Random random = new Random();
		if (random.nextInt(2) == 1){
			return new IntrinsicWeapon(20, "thwacks");
		}
		return new IntrinsicWeapon(20, "punches");
	}
}
