package game.actors;

import edu.monash.fit2099.engine.*;
import game.actions.AttackAction;
import game.actions.EnemyDieAction;
import game.actors.LordOfCinder;
import game.enums.Abilities;
import game.weapons.YhormsGreatMachete;

/**
 * Yhorm the Giant, boss under the Lord of Cinder title
 */
public class YhormTheGiant extends LordOfCinder {

    /**
     * Constructor
     */
    public YhormTheGiant() {
        super("Yhorm the Giant", 'Y', 500);
        this.addCapability(Abilities.EMBER_FORM);
        //YhormsGreatMachete yhormsGreatMachete = new YhormsGreatMachete();
        // not yet implemented in GitLab
        //this.addItemToInventory(yhormsGreatMachete);
        this.setSoul(5000);
        YhormsGreatMachete yhormsGreatMachete = new YhormsGreatMachete();
        this.addItemToInventory(yhormsGreatMachete);
    }

    /** 
     * This method returns action for Yhorm
     * @param actions       list of actions
     * @param lastAction    last action
     * @param map           game map
     * @param display       display
     * @return Action
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        if (!isConscious()){
            return new EnemyDieAction();
        }
        // loop through all behaviours
        for(game.interfaces.Behaviour Behaviour : getBehaviours()) {
            Action action = Behaviour.getAction(this, map);
            if (action != null){
                for (Action action1 : actions){
                    if (action1 instanceof AttackAction){
                        return action1;
                    }
                }
                return action;
            }
        }
        if(this.hasCapability(Abilities.EMBER_FORM)){
            if(this.hitPoints < this.maxHitPoints * 0.5){
                Weapon yhormsGreatMachete = this.getWeapon();
                ((YhormsGreatMachete) yhormsGreatMachete).rageMode();
                this.removeCapability(Abilities.EMBER_FORM);
                
            }
        }
        return new DoNothingAction();
    }   
}
