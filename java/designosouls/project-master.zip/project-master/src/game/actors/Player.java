package game.actors;

import edu.monash.fit2099.engine.*;
import game.actions.PlayerDieAction;
import game.enums.Abilities;
import game.enums.Status;
import game.grounds.Bonfire;
import game.interfaces.Resettable;
import game.interfaces.Soul;
import game.items.EstusFlask;
import game.items.GoldPineResin;
import game.weapons.BroadSword;

import java.util.ArrayList;

/**
 * Class representing the Player.
 */
public class Player extends Actor implements Soul, Resettable {
	/**
	 * Player Estus Flask Potion
	 */
	private EstusFlask potion;
	/**
	 * Player Gold Pine Resin
	 */
	private GoldPineResin goldPineResin;
	/**
	 * The soul player have
	 */
	private int soul;

	/**
	 * Menu to display player's status, health, etc.
	 */
	private final Menu menu = new Menu();

	/**
	 * Bonfire that has been activated by Player
	 */
	ArrayList<Bonfire> activatedBonfire = new ArrayList<>();

	/**
	 * Last Bonfire that Player Teleported
	 */
	private int lastBonfireKey;

	/**
	 * Constructor of Player, add it's capability, soul, instantiate it's potion and register it
	 * for it to be able to be Reset
	 * @param name        Name to call the player in the UI
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	public Player(String name, int hitPoints) {
		super(name, '@', hitPoints);
		this.maxHitPoints = hitPoints;
		this.addCapability(Status.HOSTILE_TO_ENEMY);
		this.addCapability(Abilities.REST);
		this.addCapability(Abilities.RESET);
		this.addCapability(Abilities.DRINK_ESTUS_FLASK);
		this.addCapability(Abilities.ENTER_SHRINE);
		this.addCapability(Abilities.FALL_TO_VALLEY);
		this.addCapability(Abilities.SWAP_WEAPON);
		soul = 0;
		potion = new EstusFlask(this);
		this.addItemToInventory(potion);
		goldPineResin = new GoldPineResin(this);
		this.addItemToInventory(goldPineResin);
		//add weapon after this add Broadsword
		this.addItemToInventory(new BroadSword());
		this.registerInstance();
		lastBonfireKey = 1; //The Firelink is always number 1
	}

	/**
	 * Getter to return the maxHitPoints
	 * @return int maxHitPoints
	 */
	public int getMaxHitPoints(){
		return maxHitPoints;
	}

	/**
	 * At every turn get the next action, check if player is conscious (if not do the Player Die Action,
	 * while every normal turn display it's menu showing Name + Weapon + (hitPoint/maxHitPoints) + Souls it
	 * has currently
	 * @param actions    collection of possible Actions for this Actor
	 * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
	 * @param map        the map containing the Actor
	 * @param display    the I/O object to which messages may be written
	 * @return Action action to do from it's checked condition
	 */
	@Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
		// Handle multi-turn Actions
		if (lastAction.getNextAction() != null)
			return lastAction.getNextAction();

		//IF DEAD RESET FOR WHEN DIE AT VALLEY AND NOT BY DYING BY ATTACKED BY ENEMY
		if (!this.isConscious()){
			if (this.hasCapability(Abilities.RESET)){
				return new PlayerDieAction();
			}
		}

		display.println(name + " " + this.getWeapon().toString() +" (" + hitPoints + "/" + maxHitPoints + ")" +
				" owns " + soul + " Souls");

		// return/print the console menu
		return menu.showMenu(this, actions, display);
	}

	/**
	 * Negate the player's hitpoints by points min is 0
	 * @param points number of hitpoints to deduct.
	 */
	@Override
	public void hurt(int points) {
		super.hurt(points);
		this.hitPoints = Math.max(hitPoints,0);
	}

	/**
	 * Add the player's hitPoints by points max is the maxHitPoints
	 * @param points number of hitpoints to add.
	 */
	@Override
	public void heal(int points) {
		super.heal(points);
	}

	/**
	 * Implement Soul by adding player soul by souls
	 * @param souls number of souls to be incremented.
	 * @return boolean true/ added
	 */
	@Override
	public boolean addSouls(int souls) {
		this.soul += souls;
		return true; //soul added
	}

	/**
	 * Implement Soul by decreasing this Soul to 0 because in the specification there is no such thing
	 * when only a part of scoul decreased
	 * @param souls number souls to be deducted
	 * @return boolean true/ decreased
	 */
	@Override
	public boolean subtractSouls(int souls) {
		this.soul -= souls;
		return true;
	}

	/**
	 * Implement Soul to transfer Soul to another Soul by adding their Soul and emptying player Soul
	 * @param soulObject a target souls.
	 */
	@Override
	public void transferSouls(Soul soulObject) {
		//TODO: transfer Player's souls to another Soul's instance.
		int currentSoul = this.soul;
		soulObject.addSouls(currentSoul); //add another soul it's soul
		this.subtractSouls(currentSoul); //this soul now empty
	}

	/**
	 * Reset instance, when reset heal player to max and set charges to max
	 */
	@Override
	public void resetInstance() {
		heal(maxHitPoints);
		potion.setCharges();
	}

	/**
	 * This resetInstance exist and resettable
	 * @return boolean True
	 */
	@Override
	public boolean isExist() {
		return true;
	}

	/**
	 * Set the last activated or teleported bonfire
	 * @param key ID of the last bonfire teleported too
	 */
	public void setActivatedBonfire(int key){
		lastBonfireKey = key;
	}

	/**
	 * Return the last key of the bonfire player teleported to
	 * @return int of the Bonfire's ID player last teleported to
	 */
	public int getLastBonfireKey() {
		return lastBonfireKey;
	}
}
