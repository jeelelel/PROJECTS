package game.actors;

import edu.monash.fit2099.engine.*;
import game.actors.Enemy;
import game.behaviours.WanderBehaviour;
import game.enums.Abilities;
import game.weapons.BroadSword;

public class Skeleton extends Enemy {
	Location initialLoc;

	/**
	 * Constructor
	 * @param name		name of enemy
	 * @param location	spawning location
	 */
	public Skeleton(String name, Location location) {
		super(name, 's', 100); //remove subject coz error
		initialLoc = location;
		this.setSoul(250); //250 souls
		BroadSword broadSword = new BroadSword();
		this.addItemToInventory(broadSword);
		this.registerInstance();
		this.getBehaviours().add(new WanderBehaviour());
	}

	
	/** 
	 * This method returns action for skeleton
	 * @param actions the actions
	 * @param lastAction last actions
	 * @param map the map
	 * @param display the display
	 * @return Action what action is returned from this play turn
	 */
	@Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
		Weapon broadSword = this.getWeapon();
		if (( (BroadSword) broadSword ).hasCapability(Abilities.CRIT_STRIKE)){
			( (BroadSword) broadSword ).critStrike();
		}
		return super.playTurn(actions, lastAction, map, display);
	}

}
