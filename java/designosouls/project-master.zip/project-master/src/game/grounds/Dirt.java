package game.grounds;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Exit;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import game.enums.Abilities;
import game.enums.Status;

/**
 * A class that represents bare dirt.
 */
public class Dirt extends Ground {
	/**
	 * Make the display of '.' represent dirt in the world
	 */
	public Dirt() {
		super('.');
	}

	/**
	 * Getter of the display character
	 * @return char '.'
	 */
	@Override
	public char getDisplayChar() {
		return '.';
	}

	/**
	 * Every turn at Dirt to do actions
	 * @param location The location of the Ground
	 */
	@Override
	public void tick(Location location) {
		super.tick(location);
	}

}
