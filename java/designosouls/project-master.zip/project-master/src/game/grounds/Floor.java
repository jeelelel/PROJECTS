package game.grounds;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import game.enums.Abilities;

/**
 * A class that represents the floor inside a building.
 */
public class Floor extends Ground {

	/**
	 * Construct the Floor which will be displayed by '_' at the Game Map
	 */
	public Floor() {
		super('_');
	}

	/**
	 * Every turn at Floor to do actions
	 * @param location The location of the Ground
	 */
	@Override
	public void tick(Location location) {
		super.tick(location);
	}

	/**
	 * Getter for the display char
	 * @return char '_'
	 */
	@Override
	public char getDisplayChar() {
		return super.getDisplayChar();
	}

	/**
	 * Only allow Player to step/ Enter Floor
	 * @param actor the Actor to check
	 * @return boolean Can enter or Not
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
		return actor.hasCapability(Abilities.ENTER_SHRINE);
	}
}
