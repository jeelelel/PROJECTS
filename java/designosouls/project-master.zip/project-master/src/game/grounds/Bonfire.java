package game.grounds;

import edu.monash.fit2099.engine.*;
import game.manager.BonfireManager;
import game.actions.BonfireMoveAction;
import game.actions.RestAtBonfireAction;
import game.actions.ActivateBonfireAction;
import game.enums.Abilities;

/**
 * Bonfire is a Class extended from Ground that player can rest/ reset to here
 * while its function is to Recharge health and Recharges Estus Flask and Reset Enemies
 */
public class Bonfire extends Ground{
    /**
     * Name of the bonfire
     */
    public String bonfireName;

    /**
     * Constructor for Bonfire, displaying Character 'B' as Bonfire at Game Map
     */
    public Bonfire() {
        super('B');
    }

    /**
     * Getter for display char
     * @return char 'B'
     */
    @Override
    public char getDisplayChar() {
        return super.getDisplayChar();
    }

    /**
     * Method to check each iteration of the World.run(), to do things for Bonfire, but this one not really
     * needed so far
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
    }

    /**
     * Add action to rest, so that when player near, it can chose to rest if bonfire has been activated and add
     * the action of teleporting to another activated bonfire
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return Actions RestAtBonfireAction()
     */
    @Override
    public Actions allowableActions(Actor actor, Location location, String direction) {
        Actions actions = new Actions();
        if (location.containsAnActor()) {
            if (this.hasCapability(Abilities.ACTIVATED)){
                actions.add(new RestAtBonfireAction(this));
                for (Integer activated : BonfireManager.getInstance().getBonfireDestinations().keySet()){
                    Location newLoc = BonfireManager.getInstance().getBonfireDestinations().get(activated);
                    if (activated > 0 && location != newLoc){
                        Bonfire destBonfire = (Bonfire) newLoc.getGround();
                        //actions.add(new MoveActorAction(newLoc, "to " + destBonfire.toString()));
                        actions.add(new BonfireMoveAction(newLoc, "to " + destBonfire.toString(),null,activated));
                    }
                }
            }
            else {
                actions.add(new ActivateBonfireAction());
            }
        }
        return actions;
    }

    /**
     * Because there is no name function in the Ground, this will add more naming information of each bonfire
     * @param newName String name of the bonfire
     */
    public void addName(String newName){
        bonfireName = newName;
    }

    /**
     * To strong function for bonfire naming
     * @return String bonfire name
     */
    @Override
    public String toString() {
        return bonfireName;
    }
}
