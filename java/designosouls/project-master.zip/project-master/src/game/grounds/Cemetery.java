package game.grounds;

import edu.monash.fit2099.engine.*;
import game.actors.Undead;
import game.enums.Status;

import java.util.Random;

/**
 * Extended class of Ground, Represented as Cemetery in which it will spawn Undead by 25% chance
 */
public class Cemetery extends Ground {
    /**
     * Constructor of Cemetery and in which it will displayed as 'c' in the Game Map
     */
    public Cemetery(){
        super('c');
    }

    /**
     * Basically at each iteration of World.run() each cemetery will spawn Undead by 25% chances on the Cemetery
     * in which if there is an Actor there, it will spawn at the exit of that cemetery/ nearby that cemetery to
     * keep it's 25% chances
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        Random random = new Random();
        //random 25% success to spawn undead
        boolean spawn = (random.nextInt(4)) == 0;

        if (spawn){
            Undead zombie = new Undead("Undead");
            if(!location.containsAnActor() && location.canActorEnter(zombie)){
                location.addActor(new Undead("Undead"));
            }
            else{
                for (Exit exit: location.getExits()){
                    boolean containsActor = exit.getDestination().containsAnActor();
                    boolean zombieCanEnter = exit.getDestination().canActorEnter(zombie);
                    if (!containsActor && zombieCanEnter){
                        exit.getDestination().addActor(new Undead("Undead"));
                        break;
                    }
                }
            }
        }
    }

    /**
     * Only allow zombie to enter the cemetery because in my design opinion it is weird if at the spawn place
     * of zombie, player can go in without doing nothing
     * @param actor the Actor to check
     * @return boolean Actor can enter or not
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        //Only zombie can enter, because it kinda not make sense if player can ?
        return actor.hasCapability(Status.SPAWNED);
    }
}
