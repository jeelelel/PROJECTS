package game.grounds;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;

/**
 * Wall extended from Ground
 */
public class Wall extends Ground {

	/**
	 * Constructor and displayed at Game Map by '#
	 */
	public Wall() {
		super('#');
	}

	/**
	 * Nothing can enter or step on wall
	 * @param actor the Actor to check
	 * @return boolean false/ cannot enter
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
		return false;
	}

	/**
	 * Objects can't be thrown here
	 * @return boolean true/ can't be thrown item
	 */
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}
}
