package game.grounds;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Exit;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import game.enums.Abilities;
import game.items.TokenOfSouls;

/**
 * The gorge or endless gap that is dangerous for the Player.
 */
public class Valley extends Ground {
	/**
	 * Constructor for Valley that will be displayed at map by '+'
	 */
	public Valley() {
		super('+');
	}

	/**
	 * When player step on valley, it will die then drop the Token of Soul
	 * @param location The location of the Ground
	 */
	@Override
	public void tick(Location location) {
		super.tick(location);
		if (location.getActor() != null) {
			Actor actor = location.getActor();
			if (actor.hasCapability(Abilities.FALL_TO_VALLEY)) {
				actor.hurt(Integer.MAX_VALUE); //will def die
				for(Exit exit : location.map().locationOf(actor).getExits()) {
					boolean containsActor = exit.getDestination().containsAnActor();
					boolean isDirt = exit.getDestination().getGround().getDisplayChar() == '.';
					boolean isFloor = exit.getDestination().getGround().getDisplayChar() == '_';
					if (!containsActor && (isDirt || isFloor)) {
						TokenOfSouls soulToken = new TokenOfSouls(actor.asSoul());
						exit.getDestination().addItem(soulToken);
						break;
					}
				}
			}
		}
	}


	/**
	 * Player can enter then DIE
	 * @param actor the Actor to check
	 * @return false or actor cannot enter.
	 */
	@Override
	public boolean canActorEnter(Actor actor){
		return actor.hasCapability(Abilities.FALL_TO_VALLEY);
	}

	/**
	 * Objects can't be thrown here
	 * @return boolean true/ can't be thrown item
	 */
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}
}
