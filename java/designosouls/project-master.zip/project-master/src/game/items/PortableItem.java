package game.items;

import edu.monash.fit2099.engine.Item;

/**
 * Base class for any item that can be picked up and dropped.
 */
public abstract class PortableItem extends Item {

	/**
	 * constructor
	 * @param name name of Item
	 * @param displayChar displayed as
	 */
	public PortableItem(String name, char displayChar) {
		super(name, displayChar, true);
	}
}
