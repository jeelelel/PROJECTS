package game.items;

import edu.monash.fit2099.engine.*;
import game.enums.Abilities;

import java.util.List;

public class FogDoorItem extends Item {
    public FogDoorItem(String name) {
        super(name, '=', false);
    }

    @Override
    public void tick(Location currentLocation, Actor actor) {
        super.tick(currentLocation, actor);
    }

    @Override
    public char getDisplayChar() {
        return super.getDisplayChar();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public List<Action> getAllowableActions() {
        return super.getAllowableActions();
    }

    public void addAction(Action action) {
        this.allowableActions.add(action);
    }
}
