package game.items;

import edu.monash.fit2099.engine.*;

import java.util.List;

public class CinderOfTheLord extends PortableItem {
    public CinderOfTheLord() {
        super("Cinder Of The Lord", 'C');
    }

    @Override
    public PickUpItemAction getPickUpAction(Actor actor) {
        return super.getPickUpAction(actor);
    }

    @Override
    public DropItemAction getDropAction(Actor actor) {
        //return super.getDropAction(actor);
        return null;
    }

    @Override
    public List<Action> getAllowableActions() {
        return super.getAllowableActions();
    }

    @Override
    public Weapon asWeapon() {
        return super.asWeapon();
    }
}
