package game.items;

import edu.monash.fit2099.engine.Item;
import game.actions.LightningBuffsAction;
import game.weapons.MeleeWeapon;
import game.actors.Player;
import game.enums.Status;

/**
 * Estus Flask Class that extended from Item
 */
public class GoldPineResin extends PortableItem {
    /**
     * Available charges out of 3 from Gold Pine Resin
     */
    private int charges;
    /**
     * The Player that will hold and use this Gold Pine Resin
     */
    private Player player;

    /**
     * Add action to allow player drink Estus Flask, Set charges to 3 and a constructor for EstusFlask
     * @param newPlayer Player that holds this Estus Flask
     */
    public GoldPineResin(Player newPlayer) {
        super("Gold Pine Resin", 'g');
        setCharges();
        player = newPlayer;
        this.portable = false;
        this.allowableActions.add(new LightningBuffsAction(this));
    }

    /**
     * Set charges to 3
     */
    public void setCharges() {
        this.charges = 3;
    }

    /**
     * Get the charges available
     * @return int 0-3
     */
    public int getCharges() {
        return charges;
    }

    /**
     * If available, decrement it's charges by 1 then applies lightning buffs to player weapon
     * @return boolean Charges or Not
     */
    public boolean chargeWeapon(){
        boolean check = false;
        //check how many charges available
        check = getCharges() > 0;
        if (check) {
            //minus the charges
            charges -= 1;
            ((MeleeWeapon) player.getWeapon()).lightning_charge();
            ((Item) player.getWeapon()).addCapability(Status.LIGHTNING_BUFFED);
        }
        //return Boolean whether can charge or not
        return check;
    }
}
