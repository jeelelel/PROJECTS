package game.items;

import edu.monash.fit2099.engine.Item;
import game.actors.Player;
import game.actions.DrinkEstusFlaskAction;

/**
 * Estus Flask Class that extended from Item
 */
public class EstusFlask extends Item {
    /**
     * Available charges out of 3 from Estus Flask
     */
    private int charges;
    /**
     * The Player that will hold and use this Estus Flask
     */
    private Player player;

    /**
     * Add action to allow player drink Estus Flask, Set charges to 3 and a constructor for EstusFlask
     * @param newPlayer Player that holds this Estus Flask
     */
    public EstusFlask(Player newPlayer) {
        super("Estus Flask", 'p', false);
        setCharges();
        player = newPlayer;
        this.allowableActions.add(new DrinkEstusFlaskAction(this));
    }

    /**
     * Set charges to 3
     */
    public void setCharges() {
        this.charges = 3;
    }

    /**
     * Get the charges available
     * @return int 0-3
     */
    public int getCharges() {
        return charges;
    }

    /**
     * If available, Drink Estus Flask decrement it's charges by 1 then heal Actor by its 40% maxHitHealth
     * @return boolean Charges or Not
     */
    public boolean drinkEstusFlask(){
        boolean check = false;
        //check how many charges available
        check = getCharges() > 0;
        if (check) {
            //minus the charges
            charges -= 1;
            int heal = (player.getMaxHitPoints()*40/100);
            player.heal(heal);
        }
        //return Boolean whether can charge or not
        return check;
    }

    /**
     * To String Method for this Item
     * @return String "EstusFlask(?/3)"
     */
    @Override
    public String toString() {
        return "EstusFlask (" + charges +"/3)";
    }
}
