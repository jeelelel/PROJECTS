package game.items;

import edu.monash.fit2099.engine.Item;
import game.actions.PickUpSoulsAction;
import game.interfaces.Soul;

/**
 * Token of Souls Class that extended from Item and implements Soul
 */
public class TokenOfSouls extends Item implements Soul{
    /**
     * initally its soul is 0
     */
    private int souls =0;

    /**
     * Constructor for creating thei Token of Soul Item and transfer soul of the dead player Soul
     * to this Token soul while adding action for the Token to be able to be picked up by player.
     * @param deadPlayer Soul to transferred from to Token
     */
    public TokenOfSouls(Soul deadPlayer) {
        super("Dead Player Soul Token", '$', false);
        //add int soul to token
        deadPlayer.transferSouls(this.asSoul());
        this.allowableActions.add(new PickUpSoulsAction(this));
    }

    /**
     * Add souls from dead player soul to token
     * @param deadPlayerSouls Soul to transferred from to Token
     * @return boolean added/ true
     */
    @Override
    public boolean addSouls(int deadPlayerSouls) {
        souls += deadPlayerSouls;
        return true;
    }

    /**
     * Transfer soul from this token to soulObject (Player when pick up this token)
     * @param soulObject a target souls.
     */
    @Override
    public void transferSouls(Soul soulObject) {
        soulObject.addSouls(souls);
    }

    /**
     * Getter for display char
     * @return char '$'
     */
    @Override
    public char getDisplayChar() {
        return '$';
    }
}
