package game.weapons;

import game.enums.Abilities;
import game.enums.Status;
import game.weapons.MeleeWeapon;

public class StormRuler extends MeleeWeapon {
    int charge;

    /**
     * Constructor
     */
    public StormRuler() {
        super("Storm Ruler", '7', 70, "hit", 60);
        this.addCapability(Abilities.CRIT_STRIKE);
        this.addCapability(Abilities.CHARGE_ATTACK);
        this.charge = 0;
    }
    
    /**
     * This method calls critStrike() from super
     */
    public void critStrike(){
        super.critStrike(70);
    }

    /**
     * This method charges the weapon
     */
    public void charge(){
        if (this.charge >= 2){
            this.removeCapability(Abilities.CHARGE_ATTACK);
            this.addCapability(Status.CHARGED);
        }
        else{
            if (this.hasCapability(Abilities.CHARGE_ATTACK)){
                this.charge += 1;
            }
            else{
                this.charge = 0;
            }
        }
    }

    /**
     * This method implement the charged attack
     */
    @Override
    public void chargeAttack(){
        this.hitRate = 100;
    }

    /**
     * This method resets the weapons hitrate
     */
    @Override
    public void reset_hitrate() {
        this.hitRate = 60;
    }
}