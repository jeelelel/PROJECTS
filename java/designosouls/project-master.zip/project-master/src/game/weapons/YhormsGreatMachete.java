package game.weapons;

import game.enums.Abilities;
import game.weapons.MeleeWeapon;

public class YhormsGreatMachete extends MeleeWeapon {

    /**
     * Constructor
     */
    public YhormsGreatMachete() {
        super("Yhorm's Great Machete", '!', 95, "Hit!", 60);
        this.addCapability(Abilities.RAGE_MODE);
    }

    /**
     * This method enables RAGE_MODE
     */
    public void rageMode(){
        this.hitRate = 90;
    }

}
