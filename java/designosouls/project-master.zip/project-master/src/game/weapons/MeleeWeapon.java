package game.weapons;

import java.util.Random;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.DropItemAction;
import edu.monash.fit2099.engine.PickUpItemAction;
import edu.monash.fit2099.engine.WeaponItem;
import game.actions.SwapWeaponAction;
import game.enums.Abilities;
import game.enums.Status;

public abstract class MeleeWeapon extends WeaponItem {

    int buff_charges;
    int normal_damage;

    /**
     * Constructor.
     *
     * @param name        name of the item
     * @param displayChar character to use for display when item is on the ground
     * @param damage      amount of damage this weapon does
     * @param verb        verb to use for this weapon, e.g. "hits", "zaps"
     * @param hitRate     the probability/chance to hit the target.
     */
    public MeleeWeapon(String name, char displayChar, int damage, String verb, int hitRate) {
        super(name, displayChar, damage, verb, hitRate);
    }

    /**
     * When switch weapon, when picked up the Melee Item
     * @param actor an actor that will interact with this item
     * @return PickUpItemAction when it's not player
     */
    @Override
    public PickUpItemAction getPickUpAction(Actor actor) {
        if (actor.hasCapability(Abilities.SWAP_WEAPON)){
            return new SwapWeaponAction(this);
        }
        return super.getPickUpAction(actor);
    }

    /**
     * CritStrike for the Weapon Damage
     * @param damage the critical Damage
     */
    public void critStrike(int damage){
        Random random = new Random();
        if (random.nextInt(5) == 1){
            this.damage = damage * 2;
        }
        else{
            this.damage = damage;
        }
    }

    /**
     * Charge attack empty
     */
    public void chargeAttack(){
        
    }

    /**
     * reset hit rate empty
     */
    public void reset_hitrate(){

    }

    /**
     * Prevent not dropping weapon for enemy
     * @param actor an actor that will interact with this item
     * @return
     */
    @Override
    public DropItemAction getDropAction(Actor actor) {
        /*
        if (actor.hasCapability(Abilities.SWAP_WEAPON)){
            return null;
        }

        if (this.hasCapability(Status.SWAPPED)) {
            return super.getDropAction(actor);
        }
         */
        return null;
    }



    public void lightning_charge(){
        if (buff_charges == 0){
            normal_damage = damage;
        }
        buff_charges = 10;
    }

    public void lightning_charged_attack(){
        buff_charges -= 1;
        if (buff_charges > 0){
            damage = normal_damage + 20;
            return;
        }
        damage = normal_damage;
        this.removeCapability(Status.LIGHTNING_BUFFED);
    }

}
