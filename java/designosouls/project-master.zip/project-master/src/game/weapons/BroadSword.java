package game.weapons;

import java.util.Random;

import game.enums.Abilities;

public class BroadSword extends MeleeWeapon {

    /**
     * Constructor
     */
    public BroadSword() {
        super("Broad Sword", '/', 30, "hit", 80);
        this.addCapability(Abilities.CRIT_STRIKE);
    }

    /**
     * This method doubles the weapon damage if crit
     */
    public void critStrike(){
        Random random = new Random();
        if (random.nextInt(4) == 1){
            this.damage = 60;
        }
        else{
            this.damage = 30;
        }
    }
}
