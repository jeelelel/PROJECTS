package game.weapons;

import java.util.Random;

import game.enums.Abilities;

public class DarkmoonLongbow extends MeleeWeapon {

    /**
     * Constructor
     */
    public DarkmoonLongbow() {
        super("Darkmoon Longbow", '}', 70, "Hit!", 80);
        this.addCapability(Abilities.CRIT_STRIKE);
    }

    /**
     * This method doubles the weapon damage if crit
     */
    public void critStrike(){
        Random random = new Random();
        if (random.nextInt(100) < 15){
            this.damage = 140;
        }
        else{
            this.damage = 70;
        }
    }

}
