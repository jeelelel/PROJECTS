package game.manager;

import edu.monash.fit2099.engine.Location;

import java.util.HashMap;

/**
 * This is a Bonfire manager that has an abstract instance to manage the Bonfire in this game, it manage whether a
 * bonfire is activate or not, every time player activated a bonfire than it will be added to this hashmap in increasing
 * order from 2, this excluding the Firelink bonfire that are added manually at the application as it was activated
 * in default and has key=1.
 */
public class BonfireManager {
    /**
     * Next key for the bonfire in the map, for identity of the bonfire
     */
    private Integer nextActivatedKey;
    /**
     * A hashmap containing all activated bonfire with <ID,Location> of each activated bonfire, the ID is a unique
     * positive integer.
     */
    private HashMap<Integer, Location> bonfireDestinations;
    /**
     * A singleton bonfire manager instance
     */
    private static BonfireManager instance;

    /**
     * Constructor
     */
    public BonfireManager(){
        bonfireDestinations = new HashMap<>();
        nextActivatedKey = 2;
    }

    /**
     * Get the singleton instance of reset manager
     * @return ResetManager singleton instance
     */
    public static BonfireManager getInstance(){
        if(instance == null){
            instance = new BonfireManager();
        }
        return instance;
    }

    /**
     * Function to return the next activated key
     * @return Integer of the next unique positive key that will be used in the hashmap
     */
    public Integer getNextActivatedKey(){
        return nextActivatedKey;
    }

    /**
     * Function to return the hashmap of all activated bonfire
     * @return
     */
    public HashMap<Integer, Location> getBonfireDestinations(){
        return bonfireDestinations;
    }

    /**
     * Add an activated Bonfire to the hashmap
     * @param nextKey a key from the getnextKey() function
     * @param newBonfireLoc location of the activated bonfire
     */
    public void addBonfire(Integer nextKey ,Location newBonfireLoc){
        bonfireDestinations.put(nextKey, newBonfireLoc);
        nextActivatedKey += 1;
    }


}
