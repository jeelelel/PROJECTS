package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.*;
import game.actors.AldrichTheDevourer;
import game.actors.Player;
import game.actors.Skeleton;
import game.actors.YhormTheGiant;
import game.enums.Abilities;
import game.grounds.*;
import game.items.FogDoorItem;
import game.manager.BonfireManager;
import game.weapons.StormRuler;

/**
 * The main class for the Rogue Like game.
 *
 */
public class Application {
	public static void main(String[] args) {

			World world = new World(new Display());

			//Create Player
			Actor player = new Player("Unkindled (Player)", 200);

			//add cemetery
			FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(), new Wall(),
					new Floor(), new Valley(),new Cemetery(), new Bonfire());

			//add some c's as cemetery
			List<String> map = Arrays.asList(
					"..++++++..+++...........................++++......+++.................+++.......",
					"........+++++..............................+++++++.................+++++........",
					"...........+++.....................c.................................+++++......",
					"........................................................................++......",
					".........................................................................+++....",
					"...........c................+.............................................+++...",
					".............................+++.......++++.....................................",
					".............................++.......+......................++++.........c.....",
					".............................................................+++++++............",
					"..................................###___###...................+++...............",
					"..................................#_______#......................+++............",
					"...........++.....................#___B___#.......................+.............",
					".........+++......................#_______#........................++...........",
					"............+++...................####_####..........................+..........",
					"..............+......................................................++.........",
					"....c.........++.................................................++++++.........",
					"............+++...........................................c.......++++..........",
					"+..................................................................++...........",
					"++...+++.........................................................++++...........",
					"+++......................................+++........................+.++........",
					"++++.......++++.........................++.........................+....++......",
					"#####___#####++++......................+...............................+..+.....",
					"_..._....._._#.++......................+...................................+....",
					"...+.__..+...#+++...........................................................+...",
					"...+.....+._.#.+.....+++++...++..............................................++.",
					"___.......___#.++++++++++++++.+++.............................................++");

			List<String> newMap = Arrays.asList(
					"..+++.........................................................+++.......",
					"+++++..............................++#__#+.................+++++........",
					"...+++.....................c.........#_B#....................+++++...c..",
					".....................................#__#.........c.............++......",
					".................................................................+++....",
					"...c................+.............................................+++...",
					".....................+++.......++++.....................................",
					".....................++.......+......................++++.........c.....",
					".....................................................+++++++............",
					"..........................###___###.########____#####.+++...............",
					".............c............#_______#.#......__..__...#....+++.........c..",
					"...++.....................#___B___#.#......#....#...#.....+.............",
					".+++......................#_______#.#......__..__...#......++...........",
					"....+++...................####_####.##___############........+..........",
					".c....+......................................................++.........",
					"......++.................................................++++++.........",
					"....+++...........................................c.......++++..........",
					"...........................................................++...........",
					".........................................................++++.......c...",
					"..c..............................+++........................+.++........",
					".......++++++++++++++.+++.............................................++");

			//create Game Map
			GameMap profaneCapital = new GameMap(groundFactory, map);
			world.addGameMap(profaneCapital);

			//add the new Map in
			GameMap anorLondo = new GameMap(groundFactory, newMap);
			world.addGameMap(anorLondo);

			//add player to map
			world.addPlayer(player, profaneCapital.at(38, 12));

			//fog door
			FogDoorItem fogDoorCapital = new FogDoorItem("Capital FogDoor");
			fogDoorCapital.addAction(new MoveActorAction(anorLondo.at(36,0),"to Anor Londo!"));
			profaneCapital.at(38,25).addItem(fogDoorCapital);

			FogDoorItem fogDoorAnorLondo = new FogDoorItem("AnorLondo FogDoor");
			fogDoorAnorLondo.addAction(new MoveActorAction(profaneCapital.at(38,25),"to Profane Capital!"));
			anorLondo.at(36,0).addItem(fogDoorAnorLondo);

			/*
			gameMap.at(38,25).getGround().allowableActions(player, newGameMap.at(36,0), "to Anor Londo!");
			newGameMap.at(36,0).getGround().allowableActions(player, gameMap.at(38,25),"to Profane Capital!");

			 */

			//bonfire manager singleton
			//FIRELINK
			BonfireManager.getInstance().addBonfire(1, profaneCapital.at(38,11));
			profaneCapital.at(38,11).getGround().addCapability(Abilities.ACTIVATED);
			if (profaneCapital.at(38,11).getGround().getDisplayChar() == 'B'){
				Bonfire bonfire = (Bonfire) profaneCapital.at(38,11).getGround();
				bonfire.addName("Firelink Shrine");
			}

			//Add names for other Shrine
			if (anorLondo.at(39,2).getGround().getDisplayChar() == 'B'){
				Bonfire bonfire = (Bonfire) anorLondo.at(39,2).getGround();
				bonfire.addName("Anor Londo A");
			}

			if (anorLondo.at(30,11).getGround().getDisplayChar() == 'B'){
				Bonfire bonfire = (Bonfire) anorLondo.at(30,11).getGround();
				bonfire.addName("Anor Londo B");
			}

			//add skeletons
			//CAPITAL
			profaneCapital.at(20,10).addActor(new Skeleton("Skeleton", profaneCapital.at(20,10)));
			profaneCapital.at(17,3).addActor(new Skeleton("Skeleton", profaneCapital.at(17,3)));
			profaneCapital.at(34,4).addActor(new Skeleton("Skeleton", profaneCapital.at(34,4)));
			profaneCapital.at(45,12).addActor(new Skeleton("Skeleton", profaneCapital.at(45,12)));
			profaneCapital.at(64,1).addActor(new Skeleton("Skeleton", profaneCapital.at(64,1)));
			profaneCapital.at(60,20).addActor(new Skeleton("Skeleton", profaneCapital.at(60,20)));
			profaneCapital.at(79,21).addActor(new Skeleton("Skeleton", profaneCapital.at(79,21)));
			profaneCapital.at(25,12).addActor(new Skeleton("Skeleton", profaneCapital.at(25,12)));

			//ANOR LONDO
			anorLondo.at(20,10).addActor(new Skeleton("Skeleton", anorLondo.at(20,10)));
			anorLondo.at(17,3).addActor(new Skeleton("Skeleton", anorLondo.at(17,3)));
			anorLondo.at(34,4).addActor(new Skeleton("Skeleton", anorLondo.at(34,4)));
			// newGameMap.at(45,12).addActor(new Skeleton("Skeleton", newGameMap.at(45,12)));
			anorLondo.at(64,1).addActor(new Skeleton("Skeleton", anorLondo.at(64,1)));
			anorLondo.at(13,12).addActor(new Skeleton("Skeleton", anorLondo.at(13,12)));
			anorLondo.at(16,14).addActor(new Skeleton("Skeleton", anorLondo.at(16,14)));
			anorLondo.at(19,16).addActor(new Skeleton("Skeleton", anorLondo.at(19,16)));
			anorLondo.at(16,18).addActor(new Skeleton("Skeleton", anorLondo.at(16,18)));
			anorLondo.at(19,18).addActor(new Skeleton("Skeleton", anorLondo.at(64,18)));



			// Place Yhorm the Giant/boss in the map
			profaneCapital.at(6, 25).addActor(new YhormTheGiant());

			// Place Yhorm the Giant/boss in the map
			profaneCapital.at(7, 25).addItem(new StormRuler());

			// Place Aldrich the Devourer/boss in the map
			anorLondo.at(40, 12).addActor(new AldrichTheDevourer());

			/*
			// Place a Hollow in the the map (ALREADY GENERATED FROM CEMETERY
			// FIXME: the Undead should be generated from the Cemetery
			gameMap.at(32, 7).addActor(new Undead("Undead"));

			 */

			//game runs here
			world.run();
	}
}
