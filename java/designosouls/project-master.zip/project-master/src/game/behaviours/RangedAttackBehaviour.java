package game.behaviours;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import game.actions.RangedAttackAction;
import game.interfaces.Behaviour;

public class RangedAttackBehaviour implements Behaviour {

    private Actor target;

	/**
	 * Constructor
	 * @param target	target actor
	 */
    public RangedAttackBehaviour(Actor target){
        this.target = target;
    }

	/**
	 * This method returns the attack action for enemy
	 * @param actor	attacker actor
	 * @param map	game map
	 */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        if(!map.contains(target) || !map.contains(actor))
			return null;
		
		Location here = map.locationOf(actor);
		Location there = map.locationOf(target);

		int currentDistance = distance(here, there);
		if (currentDistance <= 3){
            return new RangedAttackAction(target);
        }

		return null;
    }

    /**
	 * Compute the Manhattan distance between two locations.
	 * 
	 * @param a the first location
	 * @param b the first location
	 * @return the number of steps between a and b if you only move in the four cardinal directions.
	 */
	private int distance(Location a, Location b) {
		return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
	}
}