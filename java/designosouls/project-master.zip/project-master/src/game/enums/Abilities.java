package game.enums;

/**
 * Enum that represents an ability of Actor, Item, or Ground.
 */
public enum Abilities {
    REST, DRINK_ESTUS_FLASK, ENTER_SHRINE, FALL_TO_VALLEY, RESET, RAGE_MODE, EMBER_FORM, CRIT_STRIKE,
    SWAP_WEAPON, CHARGE_ATTACK, ACTIVATED, DROP_CINDER_OF_LORD
}
