# designosouls
FIT2099 S2 2021 Assignment
 
<br>
<br>

## Creative Mode
| Requirements                                                                                      | Features (HOW) / Your Approach / Your Answer |
| :---                                                                                              | :---        |
| Must use at least two (2) classes from the engine package.                                        | Action, Item, Weapon                              |
| Must use/re-use at least one (1) existing feature (either from A2 and/or A3 - fixed requirements) | MeleeWeapon, Player, Status, PortableItem |
| Must use existing or create new abstraction/interfaces (apart from the engine code).              | PortableItem |
| Must use existing or create new capabilities.                                                     | Status.LIGHTNING_BUFFED (new)                    |
| Must explain why it adheres to the SOLID principles.                                              | SOLID:<br>S: The classes only serve one purpose, apply electric buffs to player's weapon<br>O: GoldPineResin extends from PortableItems and can be easily maintained through Item class, LightningBuffsAction extends from Action<br>L: GoldPineResin expects a weapon item to be added the LIGHTNING_BUFFED status but all subclass of Item can be used<br>I: The classes are kept minimalistic and only uses neccessary classes<br>D: GoldPineResin depends on the Capable interface to add LIGHTNING_BUFFED status to the weapon |